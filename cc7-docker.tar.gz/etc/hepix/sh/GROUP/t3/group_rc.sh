# https://its.cern.ch/jira/browse/NOAFS-492
# shell settings for "t3" group
WWW_HOME="http://wwwth.cern.ch"; export WWW_HOME

