## https://its.cern.ch/jira/browse/NOAFS-499
## COMPASS = NA58
export STAGE_HOST=castorpublic
export STAGE_SVCCLASS=compassuser
