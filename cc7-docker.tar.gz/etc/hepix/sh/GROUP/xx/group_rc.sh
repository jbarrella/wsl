# DELPHI environment
## https://its.cern.ch/jira/browse/NOAFS-506

hpx_source "/cvmfs/delphi.cern.ch/setup.sh"
