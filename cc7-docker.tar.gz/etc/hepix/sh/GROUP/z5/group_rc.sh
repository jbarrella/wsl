# https://its.cern.ch/jira/browse/NOAFS-508
# z5 / LHCb settings
hpx_source /cvmfs/lhcb.cern.ch/lib/etc/cern_profile.sh
